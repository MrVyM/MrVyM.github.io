from Crypto.Util.number import bytes_to_long
from scalar_multiplication import weierstrass_scalar_multiplication
import matplotlib.pyplot as plt

FLAG = b'GISTRE{????????????????????????????????????}'

# Secp256k1 curve parameters
p = 2**256 - 2**32 - 977
a = 0
b = 7

# Generator
gx = 0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798
gy = 0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8
G = (gx, gy)

# Private key
d = bytes_to_long(FLAG)

fd = open('./data/power_analysis.txt', 'w+')
for _ in range(60):
    result, leak = weierstrass_scalar_multiplication(G, d, p)
    fd.write(str(leak))
fd.close()

# Graphical representation of the last power analysis
for i in range(len(leak)): # 13 graphs of 81 points
    plt.plot(leak[i * 81 : (i+1)*81])
    plt.xlabel('temps')
    plt.ylabel('consommation électrique')
    plt.savefig(f'./data/conso_{i}.png')
    plt.close()
