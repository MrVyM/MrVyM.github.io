with Ada.Text_IO; use Ada.Text_IO;
package body PassWord is
   function verification (input : String) return Boolean is
   begin
      for I in 1 .. 5 loop
         if Password (I) /= (Character'Pos (input (I)) + Character'Pos(Key (5))) then
            return False;
         end if;
      end loop;
      return True;
   end verification;
   procedure print is
      hint1 : Integer;
   begin
      for I in 1 .. 141 loop
         hint1 := (Hint (I) - Character'Pos(Key (4)));
         Ada.Text_IO.Put (Character'Val (hint1));
      end loop;
   end print;
end PassWord;
