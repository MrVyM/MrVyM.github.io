with Ada.Text_IO; use Ada.Text_IO;
with PassWord;
use PassWord;
procedure Split is
   Pass : String (1 .. 16);
   Last : Natural := 16;
begin
   while True loop
      Put_Line ("Password :");
      Get_Line (Pass, Last);
      if verification (Pass) then
         print;
         return;
      end if;
   end loop;
   return;
end Split;
